package com.example.wse

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class AppSelectionActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: AppAdapter
    private val allowedApps = mutableSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_selection)

        val prefs = getSharedPreferences("FocusPrefs", Context.MODE_PRIVATE)
        prefs.getStringSet("allowed_packages", emptySet())?.let {
            allowedApps.addAll(it)
        }

        recyclerView = findViewById(R.id.rv_apps)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val progressBar = findViewById<ProgressBar>(R.id.progress_bar)
        
        Thread {
            val apps = getInstalledApps()
            runOnUiThread {
                adapter = AppAdapter(apps, allowedApps) { pkg, isChecked ->
                    if (isChecked) allowedApps.add(pkg) else allowedApps.remove(pkg)
                }
                recyclerView.adapter = adapter
                progressBar.visibility = View.GONE
            }
        }.start()

        findViewById<Button>(R.id.btn_save_apps).setOnClickListener {
            prefs.edit().putStringSet("allowed_packages", allowedApps).apply()
            Toast.makeText(this, "Zapisano listę wyjątków", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun getInstalledApps(): List<AppInfo> {
        val pm = packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        return apps.filter { 
            (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 || it.packageName == "com.facebook.orca" 
        }.map { 
            AppInfo(
                it.loadLabel(pm).toString(),
                it.packageName,
                it.loadIcon(pm)
            )
        }.sortedBy { it.name }
    }

    data class AppInfo(val name: String, val packageName: String, val icon: Drawable)

    class AppAdapter(
        private val apps: List<AppInfo>,
        private val selected: Set<String>,
        private val onCheckChanged: (String, Boolean) -> Unit
    ) : RecyclerView.Adapter<AppAdapter.ViewHolder>() {

        class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val icon: ImageView = view.findViewById(R.id.iv_app_icon)
            val name: TextView = view.findViewById(R.id.tv_app_name)
            val pkg: TextView = view.findViewById(R.id.tv_pkg_name)
            val checkBox: CheckBox = view.findViewById(R.id.cb_app)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
            return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val app = apps[position]
            holder.name.text = app.name
            holder.pkg.text = app.packageName
            holder.icon.setImageDrawable(app.icon)
            
            holder.checkBox.setOnCheckedChangeListener(null)
            holder.checkBox.isChecked = selected.contains(app.packageName)
            holder.checkBox.setOnCheckedChangeListener { _, isChecked ->
                onCheckChanged(app.packageName, isChecked)
            }
        }

        override fun getItemCount() = apps.size
    }
}
