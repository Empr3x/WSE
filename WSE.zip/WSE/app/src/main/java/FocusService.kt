package com.example.wse

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.MediaRecorder
import android.os.*
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.PersistentCacheSettings
import java.io.File
import java.util.*
import kotlin.math.log10

class FocusService : Service(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var mediaRecorder: MediaRecorder? = null
    private val handler = Handler(Looper.getMainLooper())
    private var wakeLock: PowerManager.WakeLock? = null

    private val CHANNEL_ID = "focus_assistant_channel"
    private val NOTIFICATION_ID = 100

    private var isNear = false
    private var gravityZ = 9.8f
    private var lastMovementTime = 0L
    private var focusSessionStartedAt = 0L
    
    private var lastLightValue = 0f
    private var lastLightAlertTime = 0L
    private var lastNoiseAlertTime = 0L
    private val ALERT_COOLDOWN = 60000L

    private val environmentMonitorRunnable = object : Runnable {
        override fun run() {
            updateNoiseLevel()
            checkLightLevel(lastLightValue)
            broadcastUpdate("light_level", lastLightValue.toInt())
            handler.postDelayed(this, 5000)
        }
    }

    private val motionMonitorRunnable = object : Runnable {
        override fun run() {
            val currentTime = System.currentTimeMillis()
            val isMoving = (currentTime - lastMovementTime < 3000)
            broadcastUpdate("motion_status", if (isMoving) "Wykryto ruch!" else "Brak ruchu")
            checkFocusStatus()
            handler.postDelayed(this, 3000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        
        // Włączamy Offline Persistence w usłudze, aby zapisywać sesje bez internetu
        try {
            val db = FirebaseFirestore.getInstance()
            val settings = FirebaseFirestoreSettings.Builder()
                .setLocalCacheSettings(PersistentCacheSettings.newBuilder().build())
                .build()
            db.firestoreSettings = settings
        } catch (e: Exception) {
            Log.d("FocusService", "Firestore settings już ustawione")
        }

        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "FocusAssistant:WakeLock")
        wakeLock?.acquire(10*60*1000L)

        startForeground(NOTIFICATION_ID, createForegroundNotification())
        registerSensors()
        startMic()
        handler.post(environmentMonitorRunnable)
        handler.post(motionMonitorRunnable)
    }

    private fun createForegroundNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Asystent Skupienia", NotificationManager.IMPORTANCE_HIGH)
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Asystent Skupienia Aktywny")
            .setContentText("Monitoruję Twoje otoczenie...")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
    }

    private fun registerSensors() {
        val sensors = listOf(Sensor.TYPE_LIGHT, Sensor.TYPE_ACCELEROMETER, Sensor.TYPE_PROXIMITY, Sensor.TYPE_GYROSCOPE)
        sensors.forEach { type ->
            sensorManager.getDefaultSensor(type)?.let {
                sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
            }
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event ?: return
        val currentTime = System.currentTimeMillis()
        when (event.sensor.type) {
            Sensor.TYPE_LIGHT -> {
                lastLightValue = event.values[0]
            }
            Sensor.TYPE_ACCELEROMETER -> {
                val x = event.values[0]
                val y = event.values[1]
                val z = event.values[2]
                val magnitude = Math.sqrt((x * x + y * y + z * z).toDouble()).toFloat()

                // Logika wykrywania ruchu (większe progi - podniesienie telefonu)
                if (magnitude > 10.5 || magnitude < 9.1) {
                    lastMovementTime = currentTime
                }
            }
            Sensor.TYPE_PROXIMITY -> {
                isNear = event.values[0] < event.sensor.maximumRange
            }
            Sensor.TYPE_GYROSCOPE -> {
                // Not used
            }
        }
    }

    private fun checkLightLevel(light: Float) {
        val prefs = getSharedPreferences("FocusPrefs", Context.MODE_PRIVATE)
        if (prefs.getString("light_mode", "auto") == "disabled") return

        val currentTime = System.currentTimeMillis()
        if (currentTime - lastLightAlertTime < ALERT_COOLDOWN) return

        val minLight = prefs.getString("light_min", "500")?.toFloatOrNull() ?: 500f
        val maxLight = prefs.getString("light_max", "750")?.toFloatOrNull() ?: 750f

        if (light < minLight) {
            sendFocusNotification(101, "Oświetlenie", "Jest zbyt ciemno. Dostosuj oświetlenie do stanowiska pracy.")
            lastLightAlertTime = currentTime
        } else if (light > maxLight) {
            sendFocusNotification(101, "Oświetlenie", "Jest zbyt jasno. Dostosuj oświetlenie do stanowiska pracy.")
            lastLightAlertTime = currentTime
        }
    }

    private fun checkFocusStatus() {
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastMovementTime >= 60000) { // 1 minuta bezruchu
            if (focusSessionStartedAt == 0L) {
                focusSessionStartedAt = currentTime
                val prefs = getSharedPreferences("FocusPrefs", Context.MODE_PRIVATE)
                prefs.edit().putBoolean("is_focus_active", true).apply()
                sendFocusNotification(200, "Tryb Focus", "Uruchomiono automatycznie tryb skupienia")
            }
            broadcastUpdate("focus_status", "TRYB FOCUS AKTYWNY")
        } else {
            if (focusSessionStartedAt > 0L) {
                val durationSeconds = (currentTime - focusSessionStartedAt) / 1000
                val prefs = getSharedPreferences("FocusPrefs", Context.MODE_PRIVATE)
                prefs.edit().putBoolean("is_focus_active", false).apply()
                
                if (durationSeconds > 10) { // Zapisuj tylko sesje dłuższe niż 10s
                    saveSessionToFirestore(focusSessionStartedAt, durationSeconds, interrupted = true)
                    sendFocusNotification(1, "Raport", "Sesja skupienia zakończona. Trwała: $durationSeconds s")
                }
                focusSessionStartedAt = 0L
            }
            broadcastUpdate("focus_status", "Oczekiwanie na bezruch...")
        }
    }

    private fun saveSessionToFirestore(startTimeMillis: Long, duration: Long, interrupted: Boolean) {
        val user = FirebaseAuth.getInstance().currentUser
        if (user == null) return

        val db = FirebaseFirestore.getInstance()
        val sessionData = hashMapOf(
            "userId" to user.uid,
            "userEmail" to user.email,
            "startTime" to Date(startTimeMillis),
            "durationSeconds" to duration,
            "isInterrupted" to interrupted,
            "isSuccessfulHour" to (duration >= 3600), // 3600s = 1h
            "timestamp" to com.google.firebase.Timestamp.now()
        )

        db.collection("focus_sessions")
            .add(sessionData)
            .addOnSuccessListener {
                Log.d("FocusService", "Sesja zapisana w Firestore!")
            }
            .addOnFailureListener { e ->
                Log.e("FocusService", "Błąd zapisu sesji: ", e)
            }
    }

    private fun updateNoiseLevel() {
        mediaRecorder?.let {
            try {
                val amplitude = it.maxAmplitude
                if (amplitude > 0) {
                    val db = (20 * log10(amplitude.toDouble())).toInt()
                    broadcastUpdate("noise_db", db)
                    checkNoiseLevel(db)
                }
            } catch (e: Exception) { }
        }
    }

    private fun checkNoiseLevel(db: Int) {
        val prefs = getSharedPreferences("FocusPrefs", Context.MODE_PRIVATE)
        if (prefs.getString("volume_mode", "auto") == "disabled") return

        val currentTime = System.currentTimeMillis()
        if (currentTime - lastNoiseAlertTime < ALERT_COOLDOWN) return

        val maxNoise = prefs.getString("volume_max", "55")?.toIntOrNull() ?: 55
        if (db > maxNoise) {
            sendFocusNotification(102, "Hałas", "Za głośno! Zredukuj to zamykając drzwi do pomieszczenia.")
            lastNoiseAlertTime = currentTime
        }
    }

    override fun onDestroy() {
        if (focusSessionStartedAt > 0L) {
            val durationSeconds = (System.currentTimeMillis() - focusSessionStartedAt) / 1000
            if (durationSeconds > 10) {
                saveSessionToFirestore(focusSessionStartedAt, durationSeconds, interrupted = false)
            }
        }
        val prefs = getSharedPreferences("FocusPrefs", Context.MODE_PRIVATE)
        prefs.edit().putBoolean("is_focus_active", false).apply()
        sensorManager.unregisterListener(this)
        handler.removeCallbacks(environmentMonitorRunnable)
        handler.removeCallbacks(motionMonitorRunnable)
        if (wakeLock?.isHeld == true) wakeLock?.release()
        try {
            mediaRecorder?.stop()
            mediaRecorder?.release()
        } catch (e: Exception) { }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun broadcastUpdate(key: String, value: Any) {
        val intent = Intent("FOCUS_ASSISTANT_UPDATES")
        when (value) {
            is String -> intent.putExtra(key, value)
            is Int -> intent.putExtra(key, value)
            is Float -> intent.putExtra(key, value)
        }
        sendBroadcast(intent)
    }

    private fun sendFocusNotification(id: Int, title: String, message: String) {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(Notification.DEFAULT_ALL)
            .setAutoCancel(true)
            .build()
        
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(id, notification)
    }

    private fun startMic() {
        try {
            val outFile = File(cacheDir, "temp_audio.3gp")
            mediaRecorder = MediaRecorder().apply {
                setAudioSource(MediaRecorder.AudioSource.VOICE_RECOGNITION)
                setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP)
                setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)
                setOutputFile(outFile.absolutePath)
                prepare()
                start()
            }
        } catch (e: Exception) { }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
