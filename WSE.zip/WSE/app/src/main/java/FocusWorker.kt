package com.example.wse

import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.*
import java.util.concurrent.TimeUnit

class FocusWorker(context: Context, workerParams: WorkerParameters) : Worker(context, workerParams) {

    override fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("FocusPrefs", Context.MODE_PRIVATE)
        val mode = prefs.getString("op_mode", "manual")
        
        if (mode == "scheduled") {
            val startTime = prefs.getString("op_start", "08:00") ?: "08:00"
            val endTime = prefs.getString("op_end", "16:00") ?: "16:00"
            
            if (isCurrentTimeInInterval(startTime, endTime)) {
                startFocusService()
            } else {
                stopFocusService()
            }
        }
        
        return Result.success()
    }

    private fun isCurrentTimeInInterval(start: String, end: String): Boolean {
        try {
            val now = Calendar.getInstance()
            val currentMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
            
            val startParts = start.split(":")
            val startMinutes = startParts[0].toInt() * 60 + startParts[1].toInt()
            
            val endParts = end.split(":")
            val endMinutes = endParts[0].toInt() * 60 + endParts[1].toInt()
            
            return if (startMinutes <= endMinutes) {
                currentMinutes in startMinutes..endMinutes
            } else {
                currentMinutes >= startMinutes || currentMinutes <= endMinutes
            }
        } catch (e: Exception) {
            return false
        }
    }

    private fun startFocusService() {
        val intent = Intent(applicationContext, FocusService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            applicationContext.startForegroundService(intent)
        } else {
            applicationContext.startService(intent)
        }
    }

    private fun stopFocusService() {
        val intent = Intent(applicationContext, FocusService::class.java)
        applicationContext.stopService(intent)
    }

    companion object {
        fun schedulePeriodicWork(context: Context) {
            val workRequest = PeriodicWorkRequestBuilder<FocusWorker>(15, TimeUnit.MINUTES)
                .addTag("FocusWorkTag")
                .build()
            
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "FocusPeriodicWork",
                ExistingPeriodicWorkPolicy.KEEP,
                workRequest
            )
        }
    }
}
