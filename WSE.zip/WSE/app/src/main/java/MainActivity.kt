package com.example.wse

import android.Manifest
import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar
import java.util.Date
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.Timestamp
import com.google.firebase.firestore.Source
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.PersistentCacheSettings
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.firestore.QueryDocumentSnapshot
import android.os.Handler
import android.os.Looper
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible

class MainActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private lateinit var tvLight: TextView
    private lateinit var tvNoise: TextView
    private lateinit var tvMotion: TextView
    private lateinit var tvFocus: TextView
    private lateinit var tvStatsInterrupted: TextView
    private lateinit var tvStatsHours: TextView
    private lateinit var tvStatsAvg: TextView
    private lateinit var btnToggle: Button
    private lateinit var btnToggleStats: Button
    private lateinit var cvStats: androidx.cardview.widget.CardView
    private lateinit var spinnerPeriod: android.widget.Spinner
    private lateinit var layoutCustomDate: android.widget.LinearLayout
    private lateinit var layoutDateRange: android.widget.LinearLayout
    private lateinit var btnSelectDate: Button
    private lateinit var btnDateFrom: Button
    private lateinit var btnDateTo: Button
    private lateinit var btnApplyFilter: Button
    private var customStartDate: Date? = null
    private var customEndDate: Date? = null
    private var lastAppliedPeriod: String = "Dzisiaj"
    private lateinit var auth: FirebaseAuth
    private var isAuthVerified = false
    
    private val refreshHandler = Handler(Looper.getMainLooper())
    private val syncRunnable = object : Runnable {
        override fun run() {
            Log.d("Stats", "Planowa synchronizacja z serwerem (co 5 min)")
            loadStatistics(lastAppliedPeriod, customStartDate, customEndDate, Source.SERVER)
            refreshHandler.postDelayed(this, 5 * 60 * 1000)
        }
    }

    private val updateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "FOCUS_ASSISTANT_UPDATES") {
                if (intent.hasExtra("noise_db")) {
                    val db = intent.getIntExtra("noise_db", 0)
                    tvNoise.text = "$db dB"
                }
                if (intent.hasExtra("motion_status")) {
                    tvMotion.text = intent.getStringExtra("motion_status")
                }
                if (intent.hasExtra("focus_status")) {
                    tvFocus.text = intent.getStringExtra("focus_status")
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        FirebaseApp.initializeApp(this)
        auth = FirebaseAuth.getInstance()
        
        if (auth.currentUser == null) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        showBiometricPrompt()
    }

    private fun setupMainUI() {
        setContentView(R.layout.activity_main)

        // Inicjalizacja widoków
        tvLight = findViewById(R.id.tv_light)
        tvNoise = findViewById(R.id.tv_noise)
        tvMotion = findViewById(R.id.tv_motion)
        tvFocus = findViewById(R.id.tv_focus)
        tvStatsInterrupted = findViewById(R.id.tv_stats_interrupted)
        tvStatsHours = findViewById(R.id.tv_stats_successful_hours)
        tvStatsAvg = findViewById(R.id.tv_stats_avg_time)
        btnToggle = findViewById(R.id.btn_toggle_service)
        btnToggleStats = findViewById(R.id.btn_toggle_stats)
        cvStats = findViewById(R.id.cv_stats)
        spinnerPeriod = findViewById(R.id.spinner_stats_period)
        layoutCustomDate = findViewById(R.id.layout_custom_date)
        layoutDateRange = findViewById(R.id.layout_date_range)
        btnSelectDate = findViewById(R.id.btn_select_date)
        btnDateFrom = findViewById(R.id.btn_date_from)
        btnDateTo = findViewById(R.id.btn_date_to)
        btnApplyFilter = findViewById(R.id.btn_apply_filter)
        val btnSettings = findViewById<android.widget.ImageButton>(R.id.btn_settings)
        val btnLogout = findViewById<Button>(R.id.btn_logout)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager

        // Konfiguracja Offline Persistence (Cache)
        try {
            val db = FirebaseFirestore.getInstance()
            val settings = FirebaseFirestoreSettings.Builder()
                .setLocalCacheSettings(PersistentCacheSettings.newBuilder().build())
                .build()
            db.firestoreSettings = settings
        } catch (e: Exception) {
            Log.d("MainActivity", "Firestore settings już ustawione")
        }

        btnToggle.setOnClickListener {
            if (!isNotificationServiceEnabled()) {
                startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
                Toast.makeText(this, "Włącz dostęp do powiadomień", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (isServiceRunning(FocusService::class.java)) {
                stopFocusService()
            } else {
                checkPermissionsAndStartService()
            }
        }

        btnToggleStats.setOnClickListener {
            cvStats.isVisible = !cvStats.isVisible
            btnToggleStats.text = if (cvStats.isVisible) "UKRYJ STATYSTYKI" else "POKAŻ STATYSTYKI"
        }

        btnSettings.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }

        btnLogout.setOnClickListener {
            auth.signOut()
            GoogleSignIn.getClient(this, GoogleSignInOptions.DEFAULT_SIGN_IN).signOut().addOnCompleteListener {
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
            }
        }

        setupSpinner()
        setupDatePickers()
        
        btnApplyFilter.setOnClickListener {
            val selected = spinnerPeriod.selectedItem.toString()
            
            // Walidacja dla trybów z wyborem daty
            if (selected.startsWith("Wybierz")) {
                if (customStartDate == null || customEndDate == null) {
                    Toast.makeText(this, "Proszę najpierw wybrać datę lub przedział", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                
                if (selected == "Wybierz konkretny przedział") {
                    if (customStartDate!!.after(customEndDate)) {
                        Toast.makeText(this, "Data końcowa nie może być wcześniejsza niż początkowa", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                }
            }

            lastAppliedPeriod = selected
            loadStatistics(if (selected.startsWith("Wybierz")) "Custom" else selected, customStartDate, customEndDate, Source.CACHE)
            btnApplyFilter.visibility = View.GONE
        }

        updateButtonUI()
        FocusWorker.schedulePeriodicWork(this)
    }

    private fun showBiometricPrompt() {
        val biometricManager = BiometricManager.from(this)
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        
        when (biometricManager.canAuthenticate(authenticators)) {
            BiometricManager.BIOMETRIC_SUCCESS -> {
                val executor = ContextCompat.getMainExecutor(this)
                val biometricPrompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                        super.onAuthenticationSucceeded(result)
                        isAuthVerified = true
                        setupMainUI()
                    }

                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                        super.onAuthenticationError(errorCode, errString)
                        Toast.makeText(this@MainActivity, "Błąd autoryzacji: $errString", Toast.LENGTH_SHORT).show()
                        finish()
                    }

                    override fun onAuthenticationFailed() {
                        super.onAuthenticationFailed()
                        Toast.makeText(this@MainActivity, "Nie rozpoznano odcisku", Toast.LENGTH_SHORT).show()
                    }
                })

                val promptInfo = BiometricPrompt.PromptInfo.Builder()
                    .setTitle("Logowanie Biometryczne")
                    .setSubtitle("Użyj odcisku palca, aby wejść do aplikacji")
                    .setAllowedAuthenticators(authenticators)
                    .build()

                biometricPrompt.authenticate(promptInfo)
            }
            else -> {
                // Biometria niedostępna lub nieustawiona - pozwalamy wejść (lub można wymusić PIN)
                isAuthVerified = true
                setupMainUI()
            }
        }
    }

    private fun setupSpinner() {
        val options = arrayOf("Dzisiaj", "Ostatnie 7 dni", "Ostatnie 31 dni", "Ogółem", "Wybierz konkretny dzień", "Wybierz konkretny przedział")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, options)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerPeriod.adapter = adapter

        spinnerPeriod.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, pos: Int, p3: Long) {
                val selected = options[pos]
                layoutCustomDate.visibility = if (selected.startsWith("Wybierz")) View.VISIBLE else View.GONE
                layoutDateRange.visibility = if (selected == "Wybierz konkretny przedział") View.VISIBLE else View.GONE
                btnSelectDate.visibility = if (selected == "Wybierz konkretny dzień") View.VISIBLE else View.GONE
                
                // Resetujemy daty przy zmianie trybu, aby nie nakładały się stare filtry
                customStartDate = null
                customEndDate = null
                btnSelectDate.text = "WYBIERZ DZIEŃ"
                btnDateFrom.text = "OD:"
                btnDateTo.text = "DO:"

                // Pokazujemy przycisk "Zastosuj" przy każdej zmianie trybu
                btnApplyFilter.visibility = View.VISIBLE
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {}
        }
    }

    private fun setupDatePickers() {
        val calendar = Calendar.getInstance()
        btnSelectDate.setOnClickListener {
            android.app.DatePickerDialog(this, { _, y, m, d ->
                val cal = Calendar.getInstance()
                cal.set(y, m, d, 0, 0, 0)
                customStartDate = cal.time
                cal.set(y, m, d, 23, 59, 59)
                customEndDate = cal.time
                btnSelectDate.text = "$d-${m + 1}-$y"
                btnApplyFilter.visibility = View.VISIBLE
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
        }
        btnDateFrom.setOnClickListener {
            android.app.DatePickerDialog(this, { _, y, m, d ->
                val cal = Calendar.getInstance()
                cal.set(y, m, d, 0, 0, 0)
                customStartDate = cal.time
                btnDateFrom.text = "Od: $d-${m + 1}-$y"
                if (customEndDate != null) btnApplyFilter.visibility = View.VISIBLE
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
        }
        btnDateTo.setOnClickListener {
            android.app.DatePickerDialog(this, { _, y, m, d ->
                val cal = Calendar.getInstance()
                cal.set(y, m, d, 23, 59, 59)
                customEndDate = cal.time
                btnDateTo.text = "Do: $d-${m + 1}-$y"
                if (customStartDate != null) btnApplyFilter.visibility = View.VISIBLE
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
        }
    }

    private fun loadStatistics(period: String, customStart: Date? = null, customEnd: Date? = null, source: Source = Source.CACHE) {
        val user = auth.currentUser ?: return
        val db = FirebaseFirestore.getInstance()

        // Nie czyścimy pól tvStats...text = "...", aby dane nie "migały"
        
        var query: Query = db.collection("focus_sessions").whereEqualTo("userId", user.uid)
        val calendar = Calendar.getInstance()

        when (period) {
            "Dzisiaj" -> {
                calendar.set(Calendar.HOUR_OF_DAY, 0)
                calendar.set(Calendar.MINUTE, 0)
                calendar.set(Calendar.SECOND, 0)
                calendar.set(Calendar.MILLISECOND, 0)
                query = query.whereGreaterThanOrEqualTo("startTime", Timestamp(calendar.time))
            }
            "Ostatnie 7 dni" -> {
                calendar.add(Calendar.DAY_OF_YEAR, -7)
                calendar.set(Calendar.HOUR_OF_DAY, 0)
                calendar.set(Calendar.MINUTE, 0)
                query = query.whereGreaterThanOrEqualTo("startTime", Timestamp(calendar.time))
            }
            "Ostatnie 31 dni" -> {
                calendar.add(Calendar.DAY_OF_YEAR, -31)
                calendar.set(Calendar.HOUR_OF_DAY, 0)
                calendar.set(Calendar.MINUTE, 0)
                query = query.whereGreaterThanOrEqualTo("startTime", Timestamp(calendar.time))
            }
            "Custom", "Wybierz konkretny dzień", "Wybierz konkretny przedział" -> {
                if (customStart != null) query = query.whereGreaterThanOrEqualTo("startTime", Timestamp(customStart))
                if (customEnd != null) query = query.whereLessThanOrEqualTo("startTime", Timestamp(customEnd))
            }
        }

        query = query.orderBy("startTime", Query.Direction.DESCENDING)

        query.get(source).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val snapshots = task.result
                if (snapshots != null && !snapshots.isEmpty) {
                    processSnapshots(snapshots)
                } else {
                    if (source == Source.CACHE) {
                        // Jeśli cache pusty, spróbuj pobrać z serwera
                        loadStatistics(period, customStart, customEnd, Source.SERVER)
                    } else if (snapshots != null) {
                        // Jeśli serwer też nie ma danych, wyczyść UI (puste statystyki)
                        processSnapshots(snapshots)
                    }
                }
            } else {
                if (source == Source.CACHE) {
                    // Błąd cache'u, próbujemy serwer
                    loadStatistics(period, customStart, customEnd, Source.SERVER)
                } else {
                    // Całkowity brak danych lub błąd połączenia - zerujemy widok
                    tvStatsInterrupted.text = "0"
                    tvStatsHours.text = "0"
                    tvStatsAvg.text = "0 min"
                }
            }
        }
    }

    private fun processSnapshots(snapshots: QuerySnapshot) {
        var totalSessions = 0
        var interruptedCount = 0
        var successfulHours = 0
        var totalDuration = 0L

        // Używamy documents, aby uniknąć problemów z iteratorem w niektórych wersjach Kotlin
        for (doc in snapshots.documents) {
            totalSessions++
            val duration = doc.getLong("durationSeconds") ?: 0L
            if (doc.getBoolean("isInterrupted") == true) interruptedCount++
            if (doc.getBoolean("isSuccessfulHour") == true) successfulHours++
            totalDuration += duration
        }

        val avgTime = if (totalSessions > 0) totalDuration / totalSessions else 0
        tvStatsInterrupted.text = interruptedCount.toString()
        tvStatsHours.text = successfulHours.toString()
        tvStatsAvg.text = "${avgTime / 60} min"
    }

    private fun isNotificationServiceEnabled(): Boolean {
        val flat = android.provider.Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return flat?.contains(packageName) == true
    }

    private fun isServiceRunning(serviceClass: Class<*>): Boolean {
        val manager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return manager.getRunningServices(Int.MAX_VALUE).any { it.service.className == serviceClass.name }
    }

    private fun checkPermissionsAndStartService() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) permissions.add(Manifest.permission.FOREGROUND_SERVICE_MICROPHONE)

        if (permissions.any { ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }) {
            ActivityCompat.requestPermissions(this, permissions.toTypedArray(), 101)
        } else {
            startFocusService()
        }
    }

    private fun startFocusService() {
        val intent = Intent(this, FocusService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        updateButtonUI()
    }

    private fun stopFocusService() {
        stopService(Intent(this, FocusService::class.java))
        tvNoise.text = "-- dB"; tvMotion.text = "Wyłączono"; tvFocus.text = "Nieaktywna"
        updateButtonUI()
    }

    private fun updateButtonUI() {
        val running = isServiceRunning(FocusService::class.java)
        btnToggle.text = if (running) "WYŁĄCZ ASYSTENTA" else "URUCHOM ASYSTENTA"
        btnToggle.backgroundTintList = ContextCompat.getColorStateList(this, if (running) R.color.status_red else R.color.status_green)
    }

    override fun onResume() {
        super.onResume()
        if (!isAuthVerified) return
        updateButtonUI()
        refreshHandler.post(syncRunnable)
        loadStatistics(lastAppliedPeriod, source = Source.CACHE)
        
        val filter = IntentFilter("FOCUS_ASSISTANT_UPDATES")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(updateReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(updateReceiver, filter)
        }
        sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onPause() {
        super.onPause()
        if (!isAuthVerified) return
        sensorManager.unregisterListener(this)
        refreshHandler.removeCallbacks(syncRunnable)
        try { unregisterReceiver(updateReceiver) } catch (e: Exception) {}
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type == Sensor.TYPE_LIGHT) tvLight.text = "${event.values[0].toInt()} lx"
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.all { it == PackageManager.PERMISSION_GRANTED }) startFocusService()
    }
}
