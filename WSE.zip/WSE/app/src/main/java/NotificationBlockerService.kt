package com.example.wse

import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

class NotificationBlockerService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val sbnPackage = sbn?.packageName ?: return
        
        // Nie blokuj powiadomień własnej aplikacji (np. alertów o głośności/świetle)
        if (sbnPackage == this.packageName) return
        
        val prefs = getSharedPreferences("FocusPrefs", Context.MODE_PRIVATE)
        val isFocusActive = prefs.getBoolean("is_focus_active", false)
        
        Log.d("NotificationBlocker", "Otrzymano powiadomienie od: $sbnPackage | Tryb Focus: $isFocusActive")

        if (isFocusActive) {
            // Pobieramy listę dozwolonych aplikacji. Domyślnie pusta lista, jeśli użytkownik nic nie wybrał.
            val allowedApps = prefs.getStringSet("allowed_packages", emptySet()) ?: emptySet()
            
            if (sbnPackage !in allowedApps) {
                // Usuwamy powiadomienie, aby nie przeszkadzało
                cancelNotification(sbn.key)
                Log.d("NotificationBlocker", "ZABLOKOWANO powiadomienie od: $sbnPackage")
            } else {
                Log.d("NotificationBlocker", "DOZWOLONO powiadomienie od: $sbnPackage (jest na liście wyjątków)")
            }
        }
    }
    
    override fun onListenerConnected() {
        super.onListenerConnected()
        Log.d("NotificationBlocker", "Usługa blokowania powiadomień została połączona")
    }
}
