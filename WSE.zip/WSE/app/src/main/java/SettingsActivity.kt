package com.example.wse

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.view.isGone

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val prefs = getSharedPreferences("FocusPrefs", Context.MODE_PRIVATE)

        // --- Sekcja 1: Działanie aplikacji (Rozwijana) ---
        setupCollapsibleSection(R.id.header_operation, R.id.layout_operation_content, R.id.iv_expand_operation)
        
        val rgOpMode = findViewById<RadioGroup>(R.id.rg_operation_mode)
        val layoutOpHours = findViewById<LinearLayout>(R.id.layout_op_hours)
        val etOpStart = findViewById<EditText>(R.id.et_op_start)
        val etOpEnd = findViewById<EditText>(R.id.et_op_end)

        rgOpMode.setOnCheckedChangeListener { _, checkedId ->
            layoutOpHours.visibility = if (checkedId == R.id.rb_op_scheduled) View.VISIBLE else View.GONE
        }

        // --- Sekcja 2: Ustawienia światła ---
        setupCollapsibleSection(R.id.header_light, R.id.layout_light_content, R.id.iv_expand_light)
        
        val rgLightMode = findViewById<RadioGroup>(R.id.rg_light_mode)
        val layoutLightManual = findViewById<LinearLayout>(R.id.layout_light_manual_params)
        val etLightMin = findViewById<EditText>(R.id.et_light_min)
        val etLightMax = findViewById<EditText>(R.id.et_light_max)

        rgLightMode.setOnCheckedChangeListener { _, checkedId ->
            layoutLightManual.visibility = if (checkedId == R.id.rb_light_manual) View.VISIBLE else View.GONE
        }

        // --- Sekcja 3: Ustawienia głośności ---
        setupCollapsibleSection(R.id.header_volume, R.id.layout_volume_content, R.id.iv_expand_volume)
        
        val rgVolumeMode = findViewById<RadioGroup>(R.id.rg_volume_mode)
        val layoutVolumeManual = findViewById<LinearLayout>(R.id.layout_volume_manual_params)
        val etVolumeMin = findViewById<EditText>(R.id.et_volume_min)
        val etVolumeMax = findViewById<EditText>(R.id.et_volume_max)

        rgVolumeMode.setOnCheckedChangeListener { _, checkedId ->
            layoutVolumeManual.visibility = if (checkedId == R.id.rb_volume_manual) View.VISIBLE else View.GONE
        }

        // --- Sekcja 4: Ustawienia ruchu ---
        setupCollapsibleSection(R.id.header_motion, R.id.layout_motion_content, R.id.iv_expand_motion)
        val swMotion = findViewById<SwitchCompat>(R.id.sw_motion_detection)

        // --- Sekcja 5: Tryb Focus ---
        setupCollapsibleSection(R.id.header_focus, R.id.layout_focus_content, R.id.iv_expand_focus)
        
        val rgFocusMode = findViewById<RadioGroup>(R.id.rg_focus_mode)
        val layoutFocusManual = findViewById<LinearLayout>(R.id.layout_focus_manual_params)
        val etFocusDuration = findViewById<EditText>(R.id.et_focus_duration)
        val etBreakDuration = findViewById<EditText>(R.id.et_break_duration)

        rgFocusMode.setOnCheckedChangeListener { _, checkedId ->
            layoutFocusManual.visibility = if (checkedId == R.id.rb_focus_manual) View.VISIBLE else View.GONE
        }

        // --- Sekcja 6: Wybór aplikacji ---
        setupCollapsibleSection(R.id.header_notifications, R.id.layout_notifications_content, R.id.iv_expand_notifications)
        
        findViewById<Button>(R.id.btn_choose_apps).setOnClickListener {
            startActivity(Intent(this, AppSelectionActivity::class.java))
        }

        // --- Obsługa zapisu ---
        loadSettings(prefs, rgOpMode, etOpStart, etOpEnd, rgLightMode, etLightMin, etLightMax, 
            rgVolumeMode, etVolumeMin, etVolumeMax, swMotion, rgFocusMode, etFocusDuration, etBreakDuration)

        findViewById<Button>(R.id.btn_save_all).setOnClickListener {
            saveSettings(prefs, rgOpMode, etOpStart, etOpEnd, rgLightMode, etLightMin, etLightMax, 
                rgVolumeMode, etVolumeMin, etVolumeMax, swMotion, rgFocusMode, etFocusDuration, etBreakDuration)
            Toast.makeText(this, "Ustawienia zostały zapisane pomyślnie", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun setupCollapsibleSection(headerId: Int, contentId: Int, arrowId: Int) {
        val header = findViewById<LinearLayout>(headerId)
        val content = findViewById<LinearLayout>(contentId)
        val arrow = findViewById<ImageView>(arrowId)

        header.setOnClickListener {
            if (content.visibility == View.GONE) {
                content.visibility = View.VISIBLE
                arrow.rotation = 180f
            } else {
                content.visibility = View.GONE
                arrow.rotation = 0f
            }
        }
    }

    private fun loadSettings(prefs: android.content.SharedPreferences, rgOpMode: RadioGroup, etOpStart: EditText, etOpEnd: EditText,
                             rgLightMode: RadioGroup, etLightMin: EditText, etLightMax: EditText,
                             rgVolumeMode: RadioGroup, etVolumeMin: EditText, etVolumeMax: EditText,
                             swMotion: SwitchCompat, rgFocusMode: RadioGroup, etFocusDuration: EditText, etBreakDuration: EditText) {
        
        // Działanie
        if (prefs.getString("op_mode", "manual") == "scheduled") rgOpMode.check(R.id.rb_op_scheduled) else rgOpMode.check(R.id.rb_op_manual)
        etOpStart.setText(prefs.getString("op_start", "08:00"))
        etOpEnd.setText(prefs.getString("op_end", "16:00"))

        // Światło
        when (prefs.getString("light_mode", "auto")) {
            "manual" -> rgLightMode.check(R.id.rb_light_manual)
            "disabled" -> rgLightMode.check(R.id.rb_light_disabled)
            else -> rgLightMode.check(R.id.rb_light_auto)
        }
        etLightMin.setText(prefs.getString("light_min", "500"))
        etLightMax.setText(prefs.getString("light_max", "750"))

        // Głośność
        when (prefs.getString("volume_mode", "auto")) {
            "manual" -> rgVolumeMode.check(R.id.rb_volume_manual)
            "disabled" -> rgVolumeMode.check(R.id.rb_volume_disabled)
            else -> rgVolumeMode.check(R.id.rb_volume_auto)
        }
        etVolumeMin.setText(prefs.getString("volume_min", "35"))
        etVolumeMax.setText(prefs.getString("volume_max", "55"))

        // Ruch
        swMotion.isChecked = prefs.getBoolean("motion_enabled", true)

        // Focus
        if (prefs.getString("focus_mode", "auto") == "manual") rgFocusMode.check(R.id.rb_focus_manual) else rgFocusMode.check(R.id.rb_focus_auto)
        etFocusDuration.setText(prefs.getString("focus_duration", "60"))
        etBreakDuration.setText(prefs.getString("break_duration", "5"))
    }

    private fun saveSettings(prefs: android.content.SharedPreferences, rgOpMode: RadioGroup, etOpStart: EditText, etOpEnd: EditText,
                             rgLightMode: RadioGroup, etLightMin: EditText, etLightMax: EditText,
                             rgVolumeMode: RadioGroup, etVolumeMin: EditText, etVolumeMax: EditText,
                             swMotion: SwitchCompat, rgFocusMode: RadioGroup, etFocusDuration: EditText, etBreakDuration: EditText) {
        
        prefs.edit().apply {
            putString("op_mode", if (rgOpMode.checkedRadioButtonId == R.id.rb_op_scheduled) "scheduled" else "manual")
            putString("op_start", etOpStart.text.toString())
            putString("op_end", etOpEnd.text.toString())
            putString("light_mode", when (rgLightMode.checkedRadioButtonId) {
                R.id.rb_light_manual -> "manual"
                R.id.rb_light_disabled -> "disabled"
                else -> "auto"
            })
            putString("light_min", etLightMin.text.toString())
            putString("light_max", etLightMax.text.toString())
            putString("volume_mode", when (rgVolumeMode.checkedRadioButtonId) {
                R.id.rb_volume_manual -> "manual"
                R.id.rb_volume_disabled -> "disabled"
                else -> "auto"
            })
            putString("volume_min", etVolumeMin.text.toString())
            putString("volume_max", etVolumeMax.text.toString())
            putBoolean("motion_enabled", swMotion.isChecked)
            putString("focus_mode", if (rgFocusMode.checkedRadioButtonId == R.id.rb_focus_manual) "manual" else "auto")
            putString("focus_duration", etFocusDuration.text.toString())
            putString("break_duration", etBreakDuration.text.toString())
            apply()
        }
    }
}
